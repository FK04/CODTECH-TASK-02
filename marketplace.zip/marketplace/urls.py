from django.urls import path
from .views import ProductListView, ProductDetailView, CategoryListView, ReviewListView, UserProfileView, CartView, OrderView
from marketplace import views

urlpatterns = [
    path('user-profile/', UserProfileView.as_view(), name='user-profile'),
    path('cart/', CartView.as_view(), name='cart'),
    path('cart/<int:pk>/', CartView.as_view(), name='delete-cart-item'),
    path('orders/', OrderView.as_view(), name='orders'),
    path('products/', ProductListView.as_view(), name='product-list'),
    path('product/<int:pk>/', views.product_detail, name='product_detail'),
    path('products/<int:pk>/', ProductDetailView.as_view(), name='product-detail'),
    path('categories/', CategoryListView.as_view(), name='category-list'),
    path('reviews/', ReviewListView.as_view(), name='review-list'),
    
]
