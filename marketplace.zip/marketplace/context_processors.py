from django.conf import settings

def marketplace_name(request):
    return {
        'marketplace_name': getattr(settings, 'MARKETPLACE_NAME', 'Online Marketplace'),
    }
